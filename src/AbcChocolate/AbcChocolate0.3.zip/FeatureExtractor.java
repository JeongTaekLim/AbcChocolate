package AbcChocolate;

import java.io.IOException;

import AbcChocolate.StdAudioController;

public class FeatureExtractor {
	private static int MONO = 1;
	private static int STEREO = 2;

	// �׽�Ʈ�� �ڵ�
	public String getSvmFeature(String filePath) throws IOException {
		StdAudioController mStdAudioController = new StdAudioController(filePath);
		String svmFeature = mStdAudioController.getSvmFeature(STEREO);
		return svmFeature;
	}

}
